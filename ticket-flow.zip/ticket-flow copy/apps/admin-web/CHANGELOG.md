# Changelog
## [1.0.1] 2022-07-26

- We used the Material UI Circular Progress instead of the plugins since they were deprecated. We also removed the tilt card for the same reason. The plugins are still used in previous versions!
## [1.0.0] 2022-01-03

### Original Release
