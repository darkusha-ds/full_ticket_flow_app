// apps/admin-web/src/utils/auth.js

const ACCESS_TOKEN_KEY = "accessToken";
const USER_KEY = "user";

/**
 * Получаем токен: сначала localStorage, потом sessionStorage
 */
export function getAccessToken() {
  return localStorage.getItem(ACCESS_TOKEN_KEY) || sessionStorage.getItem(ACCESS_TOKEN_KEY);
}

export function isAuthenticated() {
  return Boolean(getAccessToken());
}

export function getStoredUser() {
  const raw =
    localStorage.getItem(USER_KEY) ||
    sessionStorage.getItem(USER_KEY);

  if (!raw) return null;

  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * Сохраняем токен + user в localStorage или sessionStorage
 */
export function saveAuth({ accessToken, user, rememberMe }) {
  clearAuth(); // чтобы не было “двойных” хранилищ

  const storage = rememberMe ? localStorage : sessionStorage;

  if (accessToken) storage.setItem(ACCESS_TOKEN_KEY, accessToken);
  if (user) storage.setItem(USER_KEY, JSON.stringify(user));
}

export function clearAuth() {
  localStorage.removeItem(ACCESS_TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  sessionStorage.removeItem(ACCESS_TOKEN_KEY);
  sessionStorage.removeItem(USER_KEY);
}

/**
 * Добавляет Authorization header если токен есть
 */
export function authHeaders(extra = {}) {
  const token = getAccessToken();
  return {
    ...extra,
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}