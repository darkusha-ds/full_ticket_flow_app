// apps/admin-web/src/components/ProtectedRoute.js

import React from "react";
import { Route, Redirect } from "react-router-dom";
import { isAuthenticated } from "utils/auth";

/**
 * Закрывает доступ на приватные страницы.
 * Если токена нет — редиректит на /authentication/sign-in
 */
export default function ProtectedRoute({ component: Component, ...rest }) {
  return (
    <Route
      {...rest}
      render={(props) => {
        if (!isAuthenticated()) {
          return (
            <Redirect
              to={{
                pathname: "/authentication/sign-in",
                state: { from: props.location },
              }}
            />
          );
        }

        return <Component {...props} />;
      }}
    />
  );
}